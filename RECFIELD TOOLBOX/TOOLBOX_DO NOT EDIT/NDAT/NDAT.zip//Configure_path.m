function [  ] = Configure_path( )
%CONFIGURE_PATH Summary of this function goes here
%   Detailed explanation goes here
addpath(genpath(pwd))