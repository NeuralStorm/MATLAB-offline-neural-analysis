function merge_matnd_files(originfilelist,destfile)

addtimesec=10;


if exist(destfile)
    merged_file=load(destfile,'-mat');
else
    merged_file=load(originfilelist{1},'-mat');
end

% infile=get_info_from_matnd(originfilelist{1});



for i=2:length(originfilelist)
    currstopev=find(strcmpi({merged_file.Events.name},'Stop')==1);
    stoptime=merged_file.Events(currstopev).ts(end);
    addtime=stoptime+addtimesec;
    
    currfile=load(originfilelist{i},'-mat');
    
    for var=fieldnames(currfile)'
        switch var{:}
            
            case 'Neurons'
                for n=1:length(merged_file.Neurons)
                    merged_file.Neurons(n).ts=cat(1,...
                        merged_file.Neurons(n).ts,addtime+...
                        currfile.Neurons(n).ts);
                end
                
            case 'Events'
                
                for e=1:length(merged_file.Events)
                    
                    merged_file.Events(e).ts=cat(1,...
                        merged_file.Events(e).ts,addtime+...
                        currfile.Events(e).ts);
                end
                
            case 'Waveforms'
                for n=1:length(merged_file.Waveforms)
                    merged_file.Waveforms(n).ts=cat(1,...
                        merged_file.Waveforms(n).ts,addtime+...
                        currfile.Waveforms(n).ts);
                    merged_file.Waveforms(n).waves=cat(1,...
                        merged_file.Waveforms(n).waves,addtime+...
                        currfile.Waveforms(n).waves);
                end
                
            case 'Continous'
                
            case 'Intervals'
                
        end
        
        
    end
    
    
end

save(destfile,'-struct','merged_file');